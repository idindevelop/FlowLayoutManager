package com.xiaofeng.flowlayoutmanager;

/**
 * Created by xhan on 4/11/16.
 */
public enum Alignment {
	LEFT,
    RIGHT,
    CENTER
}
